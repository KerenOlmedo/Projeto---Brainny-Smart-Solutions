export class Cliente{
  name: string
  birthDate: Date
  gender: string
  lastPurchaseDate: Date
  countPurchase: string
}